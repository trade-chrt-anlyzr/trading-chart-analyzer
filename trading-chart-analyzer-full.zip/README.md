# Trading Chart Analyzer - Full Version (Prototype)

This repo contains a React frontend (Vite) and a Flask backend that heuristically analyzes chart screenshots to detect Order Blocks, Fair Value Gaps, Break of Structure, Change of Character, and Liquidity Sweeps, then proposes candidate entries with SL/TP and confidence scores.

## Quick local run (without Docker)
1. Backend:
   - Install Tesseract on your system (required for OCR) and Python deps:
     - Ubuntu/Debian: `sudo apt-get install tesseract-ocr`
     - Then: `pip install -r backend/requirements.txt`
   - Run backend: `python backend/server.py` (listens on port 5000)

2. Frontend:
   - `cd frontend`
   - `npm install`
   - `npm run dev` (vite dev server, default port 5173)
   - Edit `frontend/.env` VITE_API_BASE if backend is remote

## Deploying on Render
- Push this repo to GitHub.
- Create a Web Service on Render for the `/backend` folder (Python) — it will use `render.yaml`.
- Create a Static Site on Render for the `/frontend` folder (build command `npm install && npm run build`, publish dir `dist`).
- Update frontend to use the backend public URL or set `VITE_API_BASE` env var on Render static site during build.

## Notes & Limitations
- This is a visual heuristic prototype. For reliable live trading, integrate with native OHLC data or a trained model.
- Tweak `CONFIG` in `backend/server.py` to match your chart visuals and strategy rules.
