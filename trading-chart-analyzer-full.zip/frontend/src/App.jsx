import React, {useRef, useState, useEffect} from 'react'

export default function App(){
  const [imageFile, setImageFile] = useState(null)
  const [imageURL, setImageURL] = useState(null)
  const [analyzing, setAnalyzing] = useState(false)
  const [result, setResult] = useState(null)
  const canvasRef = useRef(null)
  const imgRef = useRef(null)

  useEffect(()=>{
    if(imageURL && canvasRef.current && imgRef.current){
      const img = imgRef.current
      const canvas = canvasRef.current
      canvas.width = img.naturalWidth
      canvas.height = img.naturalHeight
      const ctx = canvas.getContext('2d')
      ctx.clearRect(0,0,canvas.width,canvas.height)
      ctx.drawImage(img,0,0)
      if(result && result.entries) drawOverlays(result, canvas)
    }
  }, [imageURL, result])

  function handleFileChange(e){
    const f = e.target.files[0]
    if(!f) return
    setImageFile(f)
    const url = URL.createObjectURL(f)
    setImageURL(url)
    setResult(null)
  }

  async function handleAnalyze(){
    if(!imageFile) return alert('Choose an image first')
    setAnalyzing(true)
    try{
      const form = new FormData()
      form.append('chart', imageFile)
      // set backend URL here or rely on proxy during dev
      const API_BASE = import.meta.env.VITE_API_BASE || 'http://localhost:5000'
      const resp = await fetch(`${API_BASE}/api/analyze`, {method:'POST', body: form})
      if(!resp.ok) throw new Error(`Server returned ${resp.status}`)
      const data = await resp.json()
      setResult(data)
    }catch(err){
      console.error(err)
      alert('Error analyzing image: '+err.message)
    }
    setAnalyzing(false)
  }

  function priceToY(price, canvas, price_range){
    if(!price_range) return canvas.height * 0.5
    const {min, max} = price_range
    const pct = (price - min) / (max - min)
    return Math.max(2, Math.min(canvas.height-2, canvas.height - pct * canvas.height))
  }

  function drawOverlays(data, canvas){
    const ctx = canvas.getContext('2d')
    ctx.lineWidth = Math.max(2, canvas.width/800)
    ctx.font = `${12 + Math.round(canvas.width/600)}px sans-serif`
    data.zones && data.zones.forEach(zone=>{
      const yTop = priceToY(zone.high, canvas, data.price_range)
      const yBottom = priceToY(zone.low, canvas, data.price_range)
      ctx.fillStyle = zone.type==='support' ? 'rgba(0,128,0,0.12)' : 'rgba(255,0,0,0.12)'
      ctx.fillRect(0, yTop, canvas.width, Math.max(2, yBottom-yTop))
      ctx.fillStyle = 'rgba(0,0,0,0.6)'
      ctx.fillText(`${zone.type} ${zone.low.toFixed(2)}-${zone.high.toFixed(2)}`, 8, yTop + 14)
    })

    data.entries && data.entries.forEach(entry=>{
      const y = priceToY(entry.price, canvas, data.price_range)
      const ySL = priceToY(entry.stop_loss, canvas, data.price_range)
      const yTP = priceToY(entry.take_profit, canvas, data.price_range)
      ctx.beginPath(); ctx.moveTo(0,y); ctx.lineTo(canvas.width,y);
      ctx.strokeStyle = entry.side === 'buy' ? 'green' : 'red'
      ctx.setLineDash([]); ctx.stroke()

      ctx.beginPath(); ctx.moveTo(0,ySL); ctx.lineTo(canvas.width,ySL);
      ctx.strokeStyle = 'black'; ctx.setLineDash([6,6]); ctx.stroke(); ctx.setLineDash([])

      ctx.beginPath(); ctx.moveTo(0,yTP); ctx.lineTo(canvas.width,yTP);
      ctx.strokeStyle = entry.side === 'buy' ? 'blue' : 'purple'; ctx.setLineDash([3,3]); ctx.stroke(); ctx.setLineDash([])

      const label = `${entry.side.toUpperCase()} ${entry.price.toFixed(4)} SL:${entry.stop_loss.toFixed(4)} TP:${entry.take_profit.toFixed(4)} (conf ${Math.round(entry.confidence*100)}%)`
      ctx.fillStyle = 'rgba(0,0,0,0.6)'
      ctx.fillRect(8, y - 22, Math.min(canvas.width-16, ctx.measureText(label).width + 12), 18)
      ctx.fillStyle = 'white'; ctx.fillText(label, 14, y - 8)
    })
  }

  function downloadCSV(){
    if(!result || !result.entries) return
    const rows = [['side','price','stop_loss','take_profit','confidence','label']]
    result.entries.forEach(e=> rows.push([e.side,e.price,e.stop_loss,e.take_profit,e.confidence,e.label]))
    const csv = rows.map(r=> r.map(c=>`"${c}"`).join(',')).join('\n')
    const blob = new Blob([csv], {type:'text/csv'})
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url; a.download = 'chart_analysis.csv'; a.click(); URL.revokeObjectURL(url)
  }

  return (
    <div style={{maxWidth:900, margin:'20px auto', fontFamily: 'sans-serif'}}>
      <h1>Trading Chart Analyzer</h1>
      <p>Upload a screenshot of a price chart and get heuristic entries (OB/FVG/BOS/LS).</p>
      <div style={{display:'flex', gap:8, marginBottom:12}}>
        <input type="file" accept="image/*" onChange={handleFileChange} />
        <button onClick={handleAnalyze} disabled={!imageFile || analyzing}>{analyzing? 'Analyzing...':'Analyze'}</button>
        <button onClick={downloadCSV} disabled={!result}>Download CSV</button>
      </div>
      <div style={{display:'flex', gap:12}}>
        <div style={{flex:1, border:'1px solid #ddd', padding:8}}>
          {!imageURL && <div style={{color:'#666'}}>No image selected</div>}
          {imageURL && (
            <div style={{position:'relative'}}>
              <img ref={imgRef} src={imageURL} alt="uploaded" style={{maxWidth:'100%', display:'block'}} onLoad={()=>{
                const canvas = canvasRef.current
                if(canvas && imgRef.current){
                  canvas.width = imgRef.current.naturalWidth
                  canvas.height = imgRef.current.naturalHeight
                  const ctx = canvas.getContext('2d')
                  ctx.drawImage(imgRef.current,0,0)
                  if(result) drawOverlays(result, canvas)
                }
              }}/>
              <canvas ref={canvasRef} style={{position:'absolute', left:0, top:0, pointerEvents:'none', width:'100%', height:'100%'}} />
            </div>
          )}
        </div>
        <div style={{width:320, border:'1px solid #ddd', padding:8}}>
          <h3>Analysis</h3>
          {!result && <div style={{color:'#666'}}>No analysis yet.</div>}
          {result && (
            <div style={{fontSize:13}}>
              <div>Detected patterns:</div>
              <ul>
                <li>Order blocks: {result.patterns.order_blocks}</li>
                <li>FVGs: {result.patterns.fvgs}</li>
                <li>BOS: {result.patterns.bos}</li>
                <li>CHOCH: {result.patterns.choch}</li>
                <li>Liquidity sweeps: {result.patterns.liquidity_sweeps}</li>
              </ul>
              <div style={{marginTop:8}}>
                <strong>Entries</strong>
                <ul>
                  {result.entries.map((e,i)=> <li key={i}><b>{e.side.toUpperCase()}</b> @ {e.price} SL: {e.stop_loss} TP: {e.take_profit} ({Math.round(e.confidence*100)}%) — {e.label}</li>)}
                </ul>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
