# server.py
from flask import Flask, request, jsonify
from flask_cors import CORS
from PIL import Image
import numpy as np
import cv2
import io
import pytesseract
from scipy.signal import find_peaks

app = Flask(__name__)
CORS(app)

# CONFIG (tweak these)
CONFIG = {
    'min_candle_width_px': 3,
    'resolution_sample_width': 800,
    'fvg_min_gap_px': 6,
    'ob_min_length_px': 8,
    'bos_min_move_px': 10,
    'ls_sweep_size_px': 12,
    'weights': {
        'ob': 0.35,
        'fvg': 0.25,
        'bos': 0.20,
        'ls': 0.20
    }
}

def load_image_bytes(img_bytes):
    pil = Image.open(io.BytesIO(img_bytes)).convert('RGB')
    return cv2.cvtColor(np.array(pil), cv2.COLOR_RGB2BGR)

def resize_for_processing(img, target_w=800):
    h,w = img.shape[:2]
    if w == target_w:
        return img, 1.0
    scale = target_w / w
    new_h = int(h * scale)
    resized = cv2.resize(img, (target_w, new_h), interpolation=cv2.INTER_AREA)
    return resized, scale

def preprocess(img):
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    blurred = cv2.GaussianBlur(gray, (5,5), 0)
    return blurred

def extract_candles_from_image(img):
    proc, scale = resize_for_processing(img, CONFIG['resolution_sample_width'])
    h,w = proc.shape[:2]
    gray = preprocess(proc)
    edges = cv2.Canny(gray, 50, 150)
    vert_proj = edges.sum(axis=0)
    from scipy.ndimage import gaussian_filter1d
    smooth = gaussian_filter1d(vert_proj.astype(float), sigma=3)
    peaks, _ = find_peaks(smooth, height=np.max(smooth)*0.12, distance=CONFIG['min_candle_width_px'])
    candles = []
    half_w = max(2, int(CONFIG['min_candle_width_px']/2))
    for p in peaks:
        x = int(p)
        x0 = max(0, x-half_w)
        x1 = min(w-1, x+half_w)
        col = proc[:, x0:x1]
        col_gray = cv2.cvtColor(col, cv2.COLOR_BGR2GRAY)
        _, th = cv2.threshold(col_gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
        row_counts = (th==0).sum(axis=1)
        nonzero_rows = np.where(row_counts > 0)[0]
        if len(nonzero_rows) < 3:
            continue
        top = int(nonzero_rows[0])
        bottom = int(nonzero_rows[-1])
        col_mean = col_gray.mean(axis=1)
        body_rows = np.where(col_mean < np.percentile(col_mean, 40))[0]
        if len(body_rows) == 0:
            body_top, body_bottom = top, bottom
        else:
            body_top, body_bottom = int(body_rows[0]), int(body_rows[-1])
        candle = {
            'x_center_px': int(x / scale),
            'open_px': int(body_top / scale),
            'close_px': int(body_bottom / scale),
            'high_px': int(top / scale),
            'low_px': int(bottom / scale)
        }
        candles.append(candle)
    candles = sorted(candles, key=lambda c: c['x_center_px'])
    return candles

def read_price_ticks(img):
    h,w = img.shape[:2]
    candidates = [img[:, int(w*0.88):w], img[:, 0:int(w*0.12)]]
    ticks = []
    for axis in candidates:
        proc = axis.copy()
        gray = cv2.cvtColor(proc, cv2.COLOR_BGR2GRAY)
        _,th = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
        sh, sw = th.shape
        scale = max(1, int(300 / max(sh, sw)))
        if scale>1:
            th = cv2.resize(th, (sw*scale, sh*scale), interpolation=cv2.INTER_LINEAR)
        config = r'--oem 3 --psm 6 -c tessedit_char_whitelist=0123456789.,'
        data = pytesseract.image_to_data(th, config=config, output_type=pytesseract.Output.DICT)
        for i,txt in enumerate(data['text']):
            txt = txt.strip()
            if not txt: continue
            cleaned = txt.replace(',', '').replace(' ', '')
            try:
                val = float(cleaned)
                y = int(data['top'][i] + data['height'][i]/2)
                axis_h = axis.shape[0]
                full_y = int(y * (img.shape[0] / axis_h))
                ticks.append((full_y, val))
            except:
                continue
        if len(ticks) >= 2:
            return ticks
    return []

def make_pixel_price_mapper(ticks, img_h):
    if len(ticks) < 2:
        return None
    ys = np.array([t[0] for t in ticks])
    ps = np.array([t[1] for t in ticks])
    coeffs = np.polyfit(ys, ps, 1)
    a,b = coeffs
    return {
        'pixel_to_price': lambda y: float(a*y + b),
        'price_to_pixel': lambda p: int((p - b)/a),
        'min': float(np.min(ps)),
        'max': float(np.max(ps))
    }

def detect_order_blocks(candles):
    obs = []
    if len(candles) < 4:
        return obs
    def body_direction(c):
        return 'bull' if c['close_px'] < c['open_px'] else 'bear'
    for i in range(0, len(candles)-2):
        cluster = candles[i:i+2]
        dir_cluster = [body_direction(c) for c in cluster]
        lookahead = candles[i+2:i+6]
        if not lookahead: continue
        dir_ahead = [body_direction(c) for c in lookahead]
        if dir_cluster.count('bear') >= 1 and dir_ahead.count('bull') >= len(lookahead)/2:
            x_positions = [c['x_center_px'] for c in cluster]
            low = min([c['low_px'] for c in cluster])
            high = max([c['high_px'] for c in cluster])
            obs.append({'type':'bullish','left_x':x_positions[0],'right_x':x_positions[-1],'low_px':low,'high_px':high,'members':cluster})
        if dir_cluster.count('bull') >= 1 and dir_ahead.count('bear') >= len(lookahead)/2:
            x_positions = [c['x_center_px'] for c in cluster]
            low = min([c['low_px'] for c in cluster])
            high = max([c['high_px'] for c in cluster])
            obs.append({'type':'bearish','left_x':x_positions[0],'right_x':x_positions[-1],'low_px':low,'high_px':high,'members':cluster})
    return obs

def detect_fvgs(candles):
    fvgs = []
    for i in range(0, len(candles)-1):
        a = candles[i]
        b = candles[i+1]
        a_body_top = min(a['open_px'], a['close_px'])
        a_body_bottom = max(a['open_px'], a['close_px'])
        b_body_top = min(b['open_px'], b['close_px'])
        b_body_bottom = max(b['open_px'], b['close_px'])
        if a_body_bottom < b_body_top - CONFIG['fvg_min_gap_px']:
            fvgs.append({'type':'bull_fvg','top_px':a_body_bottom,'bottom_px':b_body_top,'left_x':a['x_center_px'],'right_x':b['x_center_px']})
        if b_body_bottom < a_body_top - CONFIG['fvg_min_gap_px']:
            fvgs.append({'type':'bear_fvg','top_px':b_body_bottom,'bottom_px':a_body_top,'left_x':a['x_center_px'],'right_x':b['x_center_px']})
    return fvgs

def detect_bos_choch(candles):
    bos = []
    choch = []
    highs = [c['high_px'] for c in candles]
    lows = [c['low_px'] for c in candles]
    for i in range(2, len(candles)):
        prev_high = max(highs[:i-1]) if i-1>0 else highs[i-1]
        prev_low = min(lows[:i-1]) if i-1>0 else lows[i-1]
        cur_high = highs[i]
        cur_low = lows[i]
        if prev_high - cur_high > CONFIG['bos_min_move_px']:
            bos.append({'type':'bull_bos','index':i,'prev_high_px':prev_high,'cur_high_px':cur_high})
        if cur_low - prev_low > CONFIG['bos_min_move_px']:
            bos.append({'type':'bear_bos','index':i,'prev_low_px':prev_low,'cur_low_px':cur_low})
        if len(bos) >= 2:
            if bos[-2]['type'] != bos[-1]['type']:
                choch.append({'index_pair':(bos[-2]['index'], bos[-1]['index']), 'from':bos[-2]['type'], 'to':bos[-1]['type']})
    return bos, choch

def detect_liquidity_sweeps(candles):
    ls = []
    if len(candles) < 5:
        return ls
    highs = [c['high_px'] for c in candles]
    lows = [c['low_px'] for c in candles]
    for i in range(2, len(candles)):
        recent_high = min(highs[max(0,i-5):i])
        recent_low = max(lows[max(0,i-5):i])
        cur = candles[i]
        if recent_high - cur['high_px'] > CONFIG['ls_sweep_size_px']:
            ls.append({'type':'bull_ls','index':i,'ext_px': recent_high - cur['high_px']})
        if cur['low_px'] - recent_low > CONFIG['ls_sweep_size_px']:
            ls.append({'type':'bear_ls','index':i,'ext_px': cur['low_px'] - recent_low})
    return ls

def score_zone_signals(zone_signals):
    w = CONFIG['weights']
    score = 0.0
    if zone_signals.get('ob'):
        score += w['ob'] * min(1.0, len(zone_signals['ob'])/3.0)
    if zone_signals.get('fvg'):
        score += w['fvg'] * min(1.0, len(zone_signals['fvg'])/2.0)
    if zone_signals.get('bos'):
        score += w['bos'] * min(1.0, len(zone_signals['bos'])/2.0)
    if zone_signals.get('ls'):
        score += w['ls'] * min(1.0, len(zone_signals['ls'])/2.0)
    return round(min(0.99, score),3)

def build_entries_from_patterns(obs, fvgs, bos, choch, ls, mapper, img_h):
    entries = []
    for ob in obs:
        low_px = ob['low_px']
        high_px = ob['high_px']
        if mapper:
            low_p = mapper['pixel_to_price'](low_px)
            high_p = mapper['pixel_to_price'](high_px)
        else:
            low_p = (img_h - low_px) * 0.01
            high_p = (img_h - high_px) * 0.01
        zone_signals = {'ob':[ob], 'fvg':[], 'bos':[], 'ls':[]}
        for f in fvgs:
            if (f['left_x'] >= ob['left_x'] and f['right_x'] <= ob['right_x']) or (f['left_x'] <= ob['right_x'] and f['right_x'] >= ob['left_x']):
                zone_signals['fvg'].append(f)
        score = score_zone_signals(zone_signals)
        side = 'buy' if ob['type']=='bullish' else 'sell'
        center_price = (low_p + high_p) / 2.0
        sl = low_p - abs(center_price)*0.001 if side=='buy' else high_p + abs(center_price)*0.001
        tp = center_price + (abs(center_price - sl) * 2.0) if side=='buy' else center_price - (abs(center_price - sl) * 2.0)
        entries.append({'side': side, 'price': round(center_price,5), 'stop_loss': round(sl,5), 'take_profit': round(tp,5), 'confidence': score, 'label': 'order_block'})

    for f in fvgs:
        low_px = f['bottom_px']
        high_px = f['top_px']
        if mapper:
            low_p = mapper['pixel_to_price'](low_px)
            high_p = mapper['pixel_to_price'](high_px)
        else:
            low_p = (img_h - low_px) * 0.01
            high_p = (img_h - high_px) * 0.01
        side = 'buy' if f['type']=='bull_fvg' else 'sell'
        center = (low_p + high_p)/2.0
        sl = low_p - abs(center)*0.001 if side=='buy' else high_p + abs(center)*0.001
        tp = center + (abs(center-sl)*1.8) if side=='buy' else center - (abs(center-sl)*1.8)
        base_conf = 0.25
        entries.append({'side':side,'price':round(center,5),'stop_loss':round(sl,5),'take_profit':round(tp,5),'confidence':round(base_conf,3),'label':'fvg'})

    for b in bos:
        img_ref_price = (img_h/2.0) * 0.01
        side = 'buy' if b['type']=='bull_bos' else 'sell'
        price = img_ref_price
        sl = price - 0.5 if side=='buy' else price + 0.5
        tp = price + 1.0 if side=='buy' else price - 1.0
        entries.append({'side':side,'price':round(price,5),'stop_loss':round(sl,5),'take_profit':round(tp,5),'confidence':0.2,'label':'bos'})

    for l in ls:
        side = 'buy' if l['type']=='bull_ls' else 'sell'
        price = (img_h - l['ext_px']) * 0.01
        sl = price - 0.3 if side=='buy' else price + 0.3
        tp = price + 0.8 if side=='buy' else price - 0.8
        entries.append({'side':side,'price':round(price,5),'stop_loss':round(sl,5),'take_profit':round(tp,5),'confidence':0.22,'label':'liquidity_sweep'})

    dedup = {}
    for e in entries:
        key = f"{e['side']}_{round(e['price'],3)}"
        if key not in dedup or e['confidence'] > dedup[key]['confidence']:
            dedup[key] = e
    return list(dedup.values())

@app.route('/api/analyze', methods=['POST'])
def analyze_route():
    if 'chart' not in request.files:
        return jsonify({'error':'no file provided'}), 400
    f = request.files['chart']
    img_bytes = f.read()
    try:
        img = load_image_bytes(img_bytes)
        candles = extract_candles_from_image(img)
        ticks = read_price_ticks(img)
        mapper = make_pixel_price_mapper(ticks, img.shape[0]) if ticks else None
        obs = detect_order_blocks(candles)
        fvgs = detect_fvgs(candles)
        bos, choch = detect_bos_choch(candles)
        ls = detect_liquidity_sweeps(candles)
        entries = build_entries_from_patterns(obs, fvgs, bos, choch, ls, mapper, img_h=img.shape[0])
        zones = []
        for ob in obs:
            if mapper:
                zones.append({'type': 'support' if ob['type']=='bullish' else 'resistance', 'low': round(mapper['pixel_to_price'](ob['low_px']),5), 'high': round(mapper['pixel_to_price'](ob['high_px']),5)})
            else:
                zones.append({'type': 'support' if ob['type']=='bullish' else 'resistance', 'low': ob['low_px'], 'high': ob['high_px']})
        if mapper:
            price_range = {'min': mapper['min'], 'max': mapper['max']}
        else:
            prices = [e['price'] for e in entries] if entries else [0,100]
            price_range = {'min': round(min(prices)-10,5), 'max': round(max(prices)+10,5)}
        result = {
            'symbol': None,
            'timeframe': None,
            'detected_trend': 'unknown',
            'candles_count': len(candles),
            'patterns': {
                'order_blocks': len(obs),
                'fvgs': len(fvgs),
                'bos': len(bos),
                'choch': len(choch),
                'liquidity_sweeps': len(ls)
            },
            'entries': entries,
            'zones': zones,
            'price_range': price_range
        }
        return jsonify(result)
    except Exception as e:
        return jsonify({'error':str(e)}), 500

if __name__ == '__main__':
    app.run(port=5000, debug=True)
